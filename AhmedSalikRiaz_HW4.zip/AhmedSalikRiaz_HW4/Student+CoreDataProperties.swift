//
//  Student+CoreDataProperties.swift
//  AhmedSalikRiaz_HW4
//
//  Created by CTIS Student on 19.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//
//

import Foundation
import CoreData


extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student")
    }

    @NSManaged public var final: Double
    @NSManaged public var midterm: Double
    @NSManaged public var name: String?
    @NSManaged public var surname: String?

}
