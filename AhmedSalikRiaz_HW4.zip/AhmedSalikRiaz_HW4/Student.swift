//
//  Student+CoreDataClass.swift
//  AhmedSalikRiaz_HW4
//
//  Created by CTIS Student on 19.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {
    
    // Static method (class keyword)
    class func createInManagedObjectContext(_ context: NSManagedObjectContext, name: String, surname: String, midterm: NSNumber, final: NSNumber) -> Student {
        let studentObject = NSEntityDescription.insertNewObject(forEntityName: "Student", into: context) as! Student
        studentObject.name = name
        studentObject.surname = surname
        studentObject.midterm = Double(truncating: midterm)
        studentObject.final = Double(truncating: final)
        
        return studentObject
    }
}
