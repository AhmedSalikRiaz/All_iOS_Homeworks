//
//  UpdateRecordVC.swift
//  AhmedSalikRiaz_HW4
//
//  Created by CTIS Student on 19.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

protocol UpdateVCDelegate {
    func UpdateRecord(name: String, surname: String, midterm: String, final: String)
}

class UpdateRecordVC: UIViewController {
    
    @IBOutlet weak var mName: UITextField!
    @IBOutlet weak var mSurname: UITextField!
    @IBOutlet weak var mMidterm: UITextField!
    @IBOutlet weak var mFinal: UITextField!
    
    var delegate: UpdateVCDelegate?
    
    var name: String = ""
    var surname: String = ""
    var midterm: String = ""
    var final: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        mName.text = name
        mSurname.text = surname
        mMidterm.text = String(midterm)
        mFinal.text = String(final)
    }
    
    @IBAction func onUpdate(_ sender: UIBarButtonItem) {
        guard (mName.text?.isEmpty == false && mSurname.text?.isEmpty == false && mMidterm.text?.isEmpty == false && mFinal.text?.isEmpty == false) else {
                              let alert = UIAlertController(title: "Warning", message: "Textfields cannot be empty!", preferredStyle: .alert)
                              alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
        //                      NSLog("The \"OK\" alert occured.")
                              }))
                              self.present(alert, animated: true, completion: nil)
                              return
                }

                self.navigationController?.popViewController(animated: true)
                delegate?.UpdateRecord(name: mName.text!, surname: mSurname.text!, midterm: mMidterm.text!, final: mFinal.text!)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
