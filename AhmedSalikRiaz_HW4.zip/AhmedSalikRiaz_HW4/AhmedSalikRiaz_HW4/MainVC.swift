//
//  ViewController.swift
//  AhmedSalikRiaz_HW4
//
//  Created by CTIS Student on 19.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit
import CoreData         // Need to import CoreData

class MainVC: UIViewController {
    
    @IBOutlet weak var mTableView: UITableView!
    
    var newName: String?
    var newSurname: String?
    var newMidterm: String?
    var newFinal: String?
    
    // Create an empty array to store Student objects  (Recommended way)
    var mStudent = [Student]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // To insert some initial data
        //        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        
        // Everytime you will run the program this data will be inserted so comment this block
        // if you don't want to insert the data again
        //***************************************************************************************
        // Create some data to work with
        //        let dataItems = [("Mehmet", "Tas", 70.0, 95.0),
        //                         ("Fatma", "Genc", 80.0, 75.0),
        //                         ("Can", "Mehmet", 60.0, 55.0),
        //                         ("Aylin", "Koc", 65.0, 80.0)]
        //
        //        // Loop through, creating items
        //        for (name1, surname1, midterm1, final1) in dataItems {
        //            // Create individual Student instances
        //            _ = Student.createInManagedObjectContext(context, name: name1, surname: surname1, midterm: NSNumber(value: midterm1), final: NSNumber(value: final1))
        //        }
        //
        //        // Saving the data
        //        save()
        //***************************************************************************************
        
        
        // Each time this application will be executed, the data stored in Core Data should be displayed in the UITableView
        // Fill mStudent Array with data stored in Core Data
        self.fetchData()
    }
    
    // Our function to fetch data from Core Data
    func fetchData() {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
        
        // Create a sort descriptor object that sorts on the "surname"
        // property of the Core Data object
        let sortDescriptor1 = NSSortDescriptor(key: "name", ascending: true)
        let sortDescriptor2 = NSSortDescriptor(key: "surname", ascending: true)
        
        // Set the list of sort descriptors in the fetch request,
        // so it includes the sort descriptor
        fetchRequest.sortDescriptors = [sortDescriptor1, sortDescriptor2]
        
        // NSPredicate performs search operation
        // https://nspredicate.xyz
        
        //        let search = "ay"
        //        let mPredicate = NSPredicate(format: "name contains[c] %@", search)
        
        //fetchRequest.predicate = mPredicate
        
        do {
            let results = try context.fetch(fetchRequest)
            mStudent = results as! [Student]
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
        
    }
    
    // Method to insert data into Table View and save in Core Data
    func saveNewItem(_ name : String, surname : String, midterm: String, final: String) {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        // Create the new Student item
        let newStudentItem = Student.createInManagedObjectContext(context,
                                                                  name: name, surname: surname, midterm: NumberFormatter().number(from: midterm)!, final: NumberFormatter().number(from: final)!)
        
        // Update the array containing the table view row data
        self.fetchData()
        
        // Use Swift's FirstIndex function for Arrays to figure out the index of the newStudentItem
        // after it's been added and sorted in our mStudent array
        if let newStudentIndex = mStudent.firstIndex(of: newStudentItem) {
            // Create an NSIndexPath from the newStudentIndex
            let newStudentItemIndexPath = IndexPath(row: newStudentIndex, section: 0)
            // Animate in the insertion of this row
            mTableView.insertRows(at: [ newStudentItemIndexPath ], with: .automatic)
            
            save()
        }
    }
    
    func updateRecord(name: String, surname: String, midterm: String, final: String) {
        let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
        let indexpath = getIndexPathForSelectedRow()
        let std_for_upd = mStudent[indexpath!.row]
        fetchRequest.predicate = NSPredicate(format: "name == %@ AND surname == %@", std_for_upd.name!, std_for_upd.surname!)
        let result = try? managedObjectContext.fetch(fetchRequest)
        let resultData = result as! [Student]
        for object in resultData {
            
            object.name = name
            object.surname = surname
            object.midterm = Double(midterm)!
            object.final = Double(final)!
        }
        do {
            try managedObjectContext.save()
            print("Saved!")
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
    }
    
    // Method to save the Data in Core Data
    func save() {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        do {
            try context.save()
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
    }
}

extension MainVC: UITableViewDataSource, UITableViewDelegate, AddVCDelegate, UpdateVCDelegate {
    
    func AddNewRecord(name: String, surname: String, midterm: String, final: String) {
        newName = name
        newSurname = surname
        newMidterm = midterm
        newFinal = final
        
        self.saveNewItem(newName!, surname: newSurname!, midterm: newMidterm!, final: newFinal!)
        self.mTableView.reloadData()
    }
    
    func UpdateRecord(name: String, surname: String, midterm: String, final: String) {
        newName = name
        newSurname = surname
        newMidterm = midterm
        newFinal = final
        
        self.updateRecord(name: newName!, surname: newSurname!, midterm: newMidterm!, final: newFinal!)
        self.mTableView.reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mStudent.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Recommended way
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
//        print(mStudent[indexPath.row].name!)
        
        // Get the Student for this index
        let student = mStudent[indexPath.row]
        
        cell.textLabel?.text = student.name! + " " + student.surname!
        cell.detailTextLabel?.text = "Midterm = " + "\(student.midterm as Double)" + ", Final = " + "\(student.final as Double)"
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "update" {
            if let indexPath = getIndexPathForSelectedRow() {
                
                let record = mStudent[indexPath.row]
                
                let updateVC = segue.destination as! UpdateRecordVC
                
                updateVC.name = record.name!
                updateVC.surname = record.surname!
                updateVC.midterm = String(record.midterm)
                updateVC.final = String(record.final)
                
                updateVC.delegate = self
            }
        }
        
        if segue.identifier == "add" {
            let addVC = segue.destination as! AddRecordVC
            addVC.delegate = self
        }
    }
    
    // Our function to have a reference to indexPath for the TableView
    func getIndexPathForSelectedRow() -> IndexPath? {
        var indexPath: IndexPath?
        
        if mTableView.indexPathsForSelectedRows!.count > 0 {
            indexPath = mTableView.indexPathsForSelectedRows![0] as IndexPath
        }
        
        return indexPath
    }
    
}
