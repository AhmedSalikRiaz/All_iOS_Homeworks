//
//  CurrencyVC.swift
//  AhmedSalikRiaz_HW2
//
//  Created by CTIS Student on 15.11.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class CurrencyVC: UIViewController {
    
    @IBOutlet weak var firstLabel: UILabel!
    @IBOutlet weak var secondLabel: UILabel!
    @IBOutlet weak var firstTxtField: UITextField!
    @IBOutlet weak var secondTxtField: UITextField!
    
    @IBOutlet weak var currencyImg: UIImageView!
    @IBOutlet weak var currencySgmntCntrl: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        firstLabel.text = "TL (\u{20BA}):"
        secondLabel.text = "USD (\u{0024}):"
        firstTxtField.text = ""
        secondTxtField.text = ""
        secondTxtField.placeholder = "Enter USD"
        currencyImg.image = UIImage(named: "tl_usd")
    }
    
    @IBAction func onSegmentedControl(_ sender: UISegmentedControl) {
        
        switch currencySgmntCntrl.selectedSegmentIndex {
        case 0:
            firstTxtField.text = ""
            secondTxtField.text = ""
            secondLabel.text = "USD (\u{0024}):"
            secondTxtField.placeholder = "Enter USD"
            currencyImg.image = UIImage(named: "tl_usd")
        case 1:
            firstTxtField.text = ""
            secondTxtField.text = ""
            secondLabel.text = "EUR (\u{20AC}):"
            secondTxtField.placeholder = "Enter EUR"
            currencyImg.image = UIImage(named: "tl_euro")
        case 2:
            firstTxtField.text = ""
            secondTxtField.text = ""
            secondLabel.text = "GBP (\u{00A3}):"
            secondTxtField.placeholder = "Enter GBP"
            currencyImg.image = UIImage(named: "tl_gbp")
            
        default:
            break
        }
    }
    
    @IBAction func onTap(_ sender: UITapGestureRecognizer) {
        
        if currencySgmntCntrl.selectedSegmentIndex == 2 {
            currencySgmntCntrl.selectedSegmentIndex = 0
        }
        else {
            currencySgmntCntrl.selectedSegmentIndex += 1
        }
        
        // Printing the segment index ofthe segmented control
        print("\(currencySgmntCntrl.selectedSegmentIndex)")
        
        // Calling the segmented control's func so that all the changes inside it are also applied
        onSegmentedControl(currencySgmntCntrl)
    }
    
    @IBAction func txtField1EditBegin(_ sender: UITextField) {
        
        // Both the UITextFields should initialize their text to empty whenever a UITextField is selected
        firstTxtField.text = ""
        secondTxtField.text = ""
    }
    
    @IBAction func txtField2EditBegin(_ sender: UITextField) {
        
        // Both the UITextFields should initialize their text to empty whenever a UITextField is selected
        firstTxtField.text = ""
        secondTxtField.text = ""
    }
    
    @IBAction func txtField1EditChanged(_ sender: UITextField) {
        
        if let tl = Double(firstTxtField.text!) {
            
            switch currencySgmntCntrl.selectedSegmentIndex {
            case 0:
                secondTxtField.text = String(format: "%.2f", tl / 18.6) // for rounding off to 2 d.p.
                
            case 1:
                secondTxtField.text = String(format: "%.2f", tl / 18.2)
                
            case 2:
                secondTxtField.text = String(format: "%.2f", tl / 21.5)
                
            default:
                break
            }
        }
    }
    
    @IBAction func txtField2EditChanged(_ sender: UITextField) {
        
        if let otherCurrency = Double(secondTxtField.text!) {
            
            switch currencySgmntCntrl.selectedSegmentIndex {
            case 0:
                firstTxtField.text = String(format: "%.2f", otherCurrency * 18.6)
                
            case 1:
                firstTxtField.text = String(format: "%.2f", otherCurrency * 18.2)
                
            case 2:
                firstTxtField.text = String(format: "%.2f", otherCurrency * 21.5)
                
            default:
                break
            }
        }
    }
    
    
    // To close the keyboard when white area is pressed
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
