//
//  CalculationVC.swift
//  AhmedSalikRiaz_HW2
//
//  Created by CTIS Student on 15.11.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class CalculationVC: UIViewController {
    
    @IBOutlet weak var radiusVal: UITextField!
    @IBOutlet weak var heightVal: UITextField!
    @IBOutlet weak var heightLabel: UILabel!
    @IBOutlet weak var surfaceArea: UILabel!
    @IBOutlet weak var volume: UILabel!
    
    @IBOutlet weak var mSegmentedControl: UISegmentedControl!
    @IBOutlet weak var mImgView: UIImageView!
    @IBOutlet var tapGesture: UITapGestureRecognizer!
    @IBOutlet weak var calcBtn: UIButton!
    
    var area: Double?
    var vol: Double?
    var timer: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        radiusVal.text = ""
        heightVal.text = ""
        heightVal.isHidden = true
        heightLabel.isHidden = true
        surfaceArea.isHidden = true
        volume.isHidden = true
    }
    
    @IBAction func onSegmentChange(_ sender: UISegmentedControl) {
        
        switch mSegmentedControl.selectedSegmentIndex {
        case 0:
            mImgView.image = UIImage(named: "sphere")
            radiusVal.text = ""
            heightVal.text = ""
            heightVal.isHidden = true
            heightLabel.isHidden = true
            surfaceArea.isHidden = true
            volume.isHidden = true
        case 1:
            mImgView.image = UIImage(named: "cone")
            radiusVal.text = ""
            heightVal.text = ""
            heightVal.isHidden = false
            heightLabel.isHidden = false
            surfaceArea.isHidden = true
            volume.isHidden = true
        case 2:
            mImgView.image = UIImage(named: "cylinder")
            radiusVal.text = ""
            heightVal.text = ""
            heightVal.isHidden = false
            heightLabel.isHidden = false
            surfaceArea.isHidden = true
            volume.isHidden = true
            
        default:
            break
        }
    }
    
    @IBAction func onImgTap(_ sender: UITapGestureRecognizer) {
        
        if mSegmentedControl.selectedSegmentIndex == 2 {
            mSegmentedControl.selectedSegmentIndex = 0
        }
        else {
            mSegmentedControl.selectedSegmentIndex += 1
        }
        
        // Printing the segment index ofthe segmented control
        print("\(mSegmentedControl.selectedSegmentIndex)")
        
        // Calling the segmented control's func so that all the changes inside it are also applied
        onSegmentChange(mSegmentedControl)
    }
    
    @IBAction func onCalcClick(_ sender: UIButton) {
        
        // resignFirstResponder will cause the textbox that currently has focus to release focus and the keyboard will hide
        self.radiusVal.resignFirstResponder()
        self.heightVal.resignFirstResponder()
        
        let radius :Double? = Double(radiusVal.text!)
        let height :Double? = Double(heightVal.text!)
        
        // If shape is sphere
        if mSegmentedControl.selectedSegmentIndex == 0 {
            if radius == nil {
                
                let alert = UIAlertController(title: "Error", message: "Radius cannot be empty!", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: NSLocalizedString("Close", comment: "Default action"), style: .default, handler: { _ in
                    //                    NSLog("The \"OK\" alert occured.")
                }))
                
                self.present(alert, animated: true, completion: nil)
            }
            else {
                
                area = 4 * .pi * pow(radius ?? 0, 2)
                
                vol = 4/3 * .pi * pow(radius ?? 0, 3)
                
                surfaceArea.text = "Sphere Surface area = " + String(format: "%.2f", area ?? 0) // for rounding off to 2 d.p.
                volume.text = "Sphere Volume = " + String(format: "%.2f", vol ?? 0) // for rounding off to 2 d.p.
                
                self.surfaceArea.isHidden = false
                self.volume.isHidden = false
                
                self.mSegmentedControl.isEnabled = false
                self.calcBtn.isEnabled = false
                self.tapGesture.isEnabled = false
                
                Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { (_) in
                    
                    // Making these labels visible
                    self.surfaceArea.isHidden = true
                    self.volume.isHidden = true
                    
                    self.mSegmentedControl.isEnabled = true
                    self.calcBtn.isEnabled = true
                    self.tapGesture.isEnabled = true
                }
            }
        }
            
        else {
            
            if radius == nil && height == nil {
                
                let alert = UIAlertController(title: "Error", message: "Radius and Height cannot be empty!", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: NSLocalizedString("Close", comment: "Default action"), style: .default, handler: { _ in
                    //                    NSLog("The \"OK\" alert occured.")
                }))
                
                self.present(alert, animated: true, completion: nil)
            }
            else if radius == nil || height == nil {
                
                let alert = UIAlertController(title: "Error ", message: "Radius or Height cannot be empty!", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: NSLocalizedString("Close", comment: "Default action"), style: .default, handler: { _ in
                    //                    NSLog("The \"OK\" alert occured.")
                }))
                
                self.present(alert, animated: true, completion: nil)
            }
            else {
                
                // If shape is cone
                if mSegmentedControl.selectedSegmentIndex == 1 {
                    
                    let val = ((radius ?? 0) + sqrt(pow((radius ?? 0), 2) + pow((height ?? 0), 2)))
                    
                    area = .pi * (radius ?? 0) * val
                    
                    vol = 1/3 * .pi * pow(radius ?? 0, 2) * (height ?? 0)
                    
                    surfaceArea.text = "Cone Surface area = " + String(format: "%.2f", area ?? 0) // for rounding off to 2 d.p.
                    volume.text = "Cone Volume = " + String(format: "%.2f", vol ?? 0) // for rounding off to 2 d.p.
                    
                    self.surfaceArea.isHidden = false
                    self.volume.isHidden = false
                    
                    self.mSegmentedControl.isEnabled = false
                    self.calcBtn.isEnabled = false
                    self.tapGesture.isEnabled = false
                    
                    Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { (_) in
                        
                        // Making these labels visible
                        self.surfaceArea.isHidden = true
                        self.volume.isHidden = true
                        
                        self.mSegmentedControl.isEnabled = true
                        self.calcBtn.isEnabled = true
                        self.tapGesture.isEnabled = true
                    }
                }
                    
                // If shape is cylinder
                else{
                    
                    let val = ((radius ?? 0) + (height ?? 0))
                    
                    area = 2 * .pi * (radius ?? 0) * val
                    
                    vol = .pi * pow(radius ?? 0, 2) * (height ?? 0)
                    
                    surfaceArea.text = "Cylinder Surface area = " + String(format: "%.2f", area ?? 0) // for rounding off to 2 d.p.
                    volume.text = "Cylinder Volume = " + String(format: "%.2f", vol ?? 0) // for rounding off to 2 d.p.
                    
                    self.surfaceArea.isHidden = false
                    self.volume.isHidden = false
                    
                    self.mSegmentedControl.isEnabled = false
                    self.calcBtn.isEnabled = false
                    self.tapGesture.isEnabled = false
                    
                    Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { (_) in
                        
                        // Making these labels visible
                        self.surfaceArea.isHidden = true
                        self.volume.isHidden = true
                        
                        self.mSegmentedControl.isEnabled = true
                        self.calcBtn.isEnabled = true
                        self.tapGesture.isEnabled = true
                    }
                }
            }
        }
        
    }
    
    
    // To close the keyboard when white area is pressed
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
