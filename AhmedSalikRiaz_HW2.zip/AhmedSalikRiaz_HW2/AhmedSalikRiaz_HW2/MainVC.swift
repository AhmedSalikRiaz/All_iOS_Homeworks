//
//  MainVC.swift
//  AhmedSalikRiaz_HW2
//
//  Created by CTIS Student on 15.11.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class MainVC: UIViewController {
    
    let text1 = "About Controller"
    let color1 = #colorLiteral(red: 1, green: 0.1820302659, blue: 0.05994756664, alpha: 1)
    let text2 = "CTIS 480: HW2 Solution"
    let color2 = UIColor.systemIndigo
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        setBackground()
    }
    
    @IBAction func unwindToMainVC(unwindSegue:UIStoryboardSegue){}
    
    // MainVC code to set the background gradient ( call this function from viewDidLoad() )
    func setBackground() {
        // Create a gradient layer.
        let gradientLayer = CAGradientLayer()
        // Set the size of the layer to be equal to the size of display.
        gradientLayer.frame = view.bounds
        // Set an array of Core Graphics colors (.cgColor) to create the gradient.
        gradientLayer.colors = [#colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1).cgColor, #colorLiteral(red: 0.9622398019, green: 0.9249638319, blue: 0.7202355266, alpha: 1).cgColor]
        // Rasterize this static layer to improve app performance.
        gradientLayer.shouldRasterize = true
        // Apply the gradient to the view.
        self.view.layer.insertSublayer(gradientLayer, at: 0)
        
    }
    
    // Locks the application to portrait mode
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let aboutVC = segue.destination as? AboutVC{
            aboutVC.topText = text1
            aboutVC.topLabelColor = color1
            aboutVC.centerText = text2
            aboutVC.centerLabelColor = color2
        }
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
