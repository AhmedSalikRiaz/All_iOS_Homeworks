//
//  AboutVC.swift
//  AhmedSalikRiaz_HW2
//
//  Created by CTIS Student on 16.11.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class AboutVC: UIViewController {
    
    @IBOutlet weak var text1: UILabel!
    @IBOutlet weak var text2: UILabel!
    
    // Optional variables to receive data from MainVC through segue
    var topText: String!
    var centerText: String!
    var topLabelColor: UIColor!
    var centerLabelColor: UIColor!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if let topTxt = topText{
            text1.text = topTxt
        }
        if let topColor = topLabelColor{
            text1.textColor = topColor
        }
        if let midTxt = centerText{
            text2.text = midTxt
        }
        if let midColor = centerLabelColor{
            text2.textColor = midColor
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
