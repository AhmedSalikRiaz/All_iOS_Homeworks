//
//  CustomCollectionReusableView.swift
//  AhmedSalikRiaz_HW3
//
//  Created by CTIS Student on 15.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class HeaderCollectionReusableView: UICollectionReusableView {
        
    @IBOutlet weak var headerLabel: UILabel!
}
