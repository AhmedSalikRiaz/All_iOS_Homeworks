//
//  JsonVC.swift
//  AhmedSalikRiaz_HW3
//
//  Created by CTIS Student on 14.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class JsonVC: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var mTableView: UITableView!
    
    let mDataSource = DataSource()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        mDataSource.populate(type: "json")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return mDataSource.numberOfCategories()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mDataSource.numbeOfItemsInEachCategory(index: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //var cell = UITableViewCell()
        
        // Recommended way
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        let records: [Record] = mDataSource.itemsInCategory(index: indexPath.section)
        let record = records[indexPath.row]
        
        cell.textLabel?.text = record.name
        cell.imageView?.image = UIImage(named: record.image.lowercased())
        
        return cell
    }
    
    // Setting the header height for each section
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40.0
    }
    
    // Setting the header title for each section
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let label : UILabel = UILabel()
        
        label.text = mDataSource.getCategoryLabelAtIndex(index: section)
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 20.0)
        label.textColor = UIColor.red
        label.backgroundColor = #colorLiteral(red: 0.9686274529, green: 0.78039217, blue: 0.3450980484, alpha: 1)
        label.textAlignment = .center
        
        return label
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let indexPath = getIndexPathForSelectedRow() {
            
            let record = mDataSource.itemsInCategory(index: indexPath.section)[indexPath.row]
            
            let detailViewController = segue.destination as! DetailVC
            
            detailViewController.mRecord = record
            
            detailViewController.navigationItem.title = record.name
        }
    }
    
     // Our function to have a reference to indexPath for the TableView
    func getIndexPathForSelectedRow() -> IndexPath? {
        var indexPath: IndexPath?
        
        if mTableView.indexPathsForSelectedRows!.count > 0 {
            indexPath = mTableView.indexPathsForSelectedRows![0] as IndexPath
        }
        
        return indexPath
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
