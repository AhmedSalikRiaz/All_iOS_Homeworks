//
//  CustomCollectionViewCell.swift
//  AhmedSalikRiaz_HW3
//
//  Created by CTIS Student on 15.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImageView: UIImageView!
    @IBOutlet weak var cellLabel: UILabel!
}
