//
//  XmlVC.swift
//  AhmedSalikRiaz_HW3
//
//  Created by CTIS Student on 14.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class XmlVC: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet weak var mCollectionView: UICollectionView!
    
    let mDataSource = DataSource()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        mDataSource.populate(type: "xml")
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return mDataSource.numberOfCategories()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return mDataSource.numbeOfItemsInEachCategory(index: section)
    }
    
    // For each cell setting the data
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CustomCollectionViewCell
        
        let records: [Record] = mDataSource.itemsInCategory(index: indexPath.section)
        let record = records[indexPath.row]

        cell.cellLabel?.text = record.name
        cell.cellImageView?.image = UIImage(named: record.image.lowercased())
        
        return cell
    }
    
    // For each header setting the data
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "header", for: indexPath) as! HeaderCollectionReusableView
        
        headerView.headerLabel.text = mDataSource.getCategoryLabelAtIndex(index: indexPath.section)
        
        return headerView
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let indexPath = getIndexPathForSelectedCell() {
            
            let record = mDataSource.itemsInCategory(index: indexPath.section)[indexPath.row]
            
            let detailViewController = segue.destination as! DetailVC
            
            detailViewController.mRecord = record
            
            detailViewController.navigationItem.title = record.name
        }
    }
    
    // Our function to find the indexPath of selected cell
    func getIndexPathForSelectedCell() -> IndexPath? {
        var indexPath: IndexPath?
        
        if mCollectionView.indexPathsForSelectedItems!.count > 0 {
            indexPath = mCollectionView.indexPathsForSelectedItems![0] as IndexPath
        }
                
        return indexPath
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
