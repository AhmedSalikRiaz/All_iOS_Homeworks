//
//  AboutVC.swift
//  AhmedSalikRiaz_HW1
//
//  Created by CTIS Student on 27.10.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class AboutVC: UIViewController {

    @IBOutlet weak var topLabel: UILabel!
    @IBOutlet weak var centerLabel: UILabel!
    
    // Optional variables to receive data from StartVC through segue
    var topText: String!
    var centerText: String!
    var centerLabelColor: UIColor!
    var centerLabelStyle: UIFont!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if let topLabelText = topText {
            topLabel.text = topLabelText
        }
        if let centerLabelText = centerText {
            centerLabel.text = centerLabelText
        }
        if let color = centerLabelColor {
            centerLabel.textColor = color
        }
        if let style = centerLabelStyle {
            centerLabel.font = style
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
