//
//  StartVC.swift
//  AhmedSalikRiaz_HW1
//
//  Created by CTIS Student on 21.10.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class StartVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

