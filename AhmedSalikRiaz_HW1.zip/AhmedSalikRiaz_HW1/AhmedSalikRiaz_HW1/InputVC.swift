//
//  InputVC.swift
//  AhmedSalikRiaz_HW1
//
//  Created by CTIS Student on 29.10.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit
protocol InputVCDelegate {
    func AreaandVolumeDatas(data: (Double, Double, String))
}

class InputVC: UIViewController {
    
    var title_for_input: String = ""
    var area: Double?
    var volume: Double?
    var delegate: InputVCDelegate?
    
    @IBOutlet weak var radiusTextView: UITextField!
    @IBOutlet weak var heightTextView: UITextField!
    @IBOutlet weak var labelForHeight: UILabel!
    
    @IBAction func doneBtnClicked(_ sender: UIBarButtonItem) {
        if radiusTextView.isHidden == false {
              guard (radiusTextView.text?.isEmpty == false) else {
                           let alert = UIAlertController(title: "Warning", message: "Textfields cannot be empty!", preferredStyle: .alert)
                           alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                           NSLog("The \"OK\" alert occured.")
                           }))
                           self.present(alert, animated: true, completion: nil)
                           return
             }
              }
              if heightTextView.isHidden == false {
              guard (heightTextView.text?.isEmpty == false) else {
                                  let alert = UIAlertController(title: "Warning", message: "Textfields cannot be empty!", preferredStyle: .alert)
                                  alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                                  NSLog("The \"OK\" alert occured.")
                                  }))
                                  self.present(alert, animated: true, completion: nil)
                                  return
                    }
              }
              let radius_val :Double? = Double(radiusTextView.text!)
              let height_val :Double? = Double(heightTextView.text!)
            /*  let WHtR = ((waist_val ?? 0) / (height_val ?? 0)) * 100
              let roundedWHtR = round(WHtR * 100) / 100.0*/
              if self.title == "Sphere" {
                  area = 4 * .pi * pow(radius_val ?? 0, 2)
                  
                  
                  volume = 4/3 * .pi * pow(radius_val ?? 0, 3)
                  
              
              }
             else if self.title == "Cone" {
                let val = ((radius_val ?? 0) + sqrt(pow((radius_val ?? 0), 2) + pow((height_val ?? 0), 2)))
                area = .pi * (radius_val ?? 0) * val
                        
                volume = 1/3 * .pi * pow(radius_val ?? 0, 2) * (height_val ?? 0)
            
        
             }
              else{
                let val = ((radius_val ?? 0) + (height_val ?? 0))
               area = 2 * .pi * (radius_val ?? 0) * val
                
                volume = .pi * pow(radius_val ?? 0, 2) * (height_val ?? 0)
              }
              let rounded_area = round((area ?? 0) * 100) / 100.0
              let rounded_volume = round((volume ?? 0) * 100) / 100.0
              self.navigationController?.popViewController(animated: true)
              delegate?.AreaandVolumeDatas(data: (rounded_area,rounded_volume, self.title ?? "Sphere"))
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if title_for_input != "" {
        self.title = title_for_input
        }
        else{
            self.title = "Sphere"
        }
        if self.title == "Sphere" {
            heightTextView.isHidden = true
            labelForHeight.isHidden = true
                
            
        }
        else{
            heightTextView.isHidden = false
            labelForHeight.isHidden = false
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
         self.view.endEditing(true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
