//
//  ViewController.swift
//  AhmedSalikRiaz_HW1
//
//  Created by CTIS Student on 21.10.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class StartVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var mSegmentedControl: UISegmentedControl!
    @IBOutlet weak var mLabel: UILabel!
    @IBOutlet weak var mPickerView: UIPickerView!
    @IBOutlet weak var mImageView: UIImageView!
    
    
    let colors = ["red", "green", "blue", "yellow", "pink"]
    var selectedColor: UIColor!
    var row_selected_from_pw: Int?
    
    var counterForGameVC: Int = 0
    
    
    //this protocol stub is necessary when UIPickerViewDataSource is added
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of items/rows in the components
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return colors.count
    }
    
    // Called automatically multiple times. To attach the data
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return colors[row]
    }
    
    // So that color selection can be stored and shared to GameVC
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        row_selected_from_pw = row
        switch row {
        case 0:
            selectedColor = #colorLiteral(red: 1, green: 0.2252420353, blue: 0.2439681457, alpha: 1)     // Write -> Color Literal
        case 1:
            selectedColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
        case 2:
            selectedColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        case 3:
            selectedColor = #colorLiteral(red: 0.9281515903, green: 0.9607843161, blue: 0.1096908993, alpha: 1)
        case 4:
            selectedColor = #colorLiteral(red: 0.8549019694, green: 0.3939254173, blue: 0.8021209406, alpha: 1)
        default:
            selectedColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
    }
    
    @IBAction func onLongPressGestureRecognizer(_ sender: UILongPressGestureRecognizer) {
        
        if mSegmentedControl.selectedSegmentIndex == 0  {
            performSegue(withIdentifier: "toCalculation", sender: self)
        }
        if mSegmentedControl.selectedSegmentIndex == 1  {
            performSegue(withIdentifier: "toWhtr", sender: self)
        }
        //make prepare func for this identifier like in segue2.zip
        if mSegmentedControl.selectedSegmentIndex == 2  {
            counterForGameVC += 1
            performSegue(withIdentifier: "toGame", sender: self)
        }
        if mSegmentedControl.selectedSegmentIndex == 3  {
            performSegue(withIdentifier: "toPlayer", sender: self)
        }
        if mSegmentedControl.selectedSegmentIndex == 4  {
            performSegue(withIdentifier: "toAbout", sender: self)
        }
    }
    
    @IBAction func onTapGestureRecognizer(_ sender: UITapGestureRecognizer) {
        
        if mSegmentedControl.selectedSegmentIndex == 4 {
            mSegmentedControl.selectedSegmentIndex = 0
        }
        else {
            mSegmentedControl.selectedSegmentIndex += 1
        }
        
        onSegmentChanged(mSegmentedControl)
    }
    
    @IBAction func onSegmentChanged(_ sender: UISegmentedControl) {
        
        switch mSegmentedControl.selectedSegmentIndex {  // switch sender.selectedSegmentIndex
        case 0:
            mLabel.text = "Calculation Controller"
            mPickerView.isHidden = true
            mImageView.image = UIImage(named:"calculation")
        case 1:
            mLabel.text = "WHtR Controller"
            mPickerView.isHidden = true
            mImageView.image = UIImage(named:"whtr")
        case 2:
            mLabel.text = "Game Controller"
            mPickerView.isHidden = false
            mImageView.image = UIImage(named:"game")
        case 3:
            mLabel.text = "Player Controller"
            mPickerView.isHidden = true
            mImageView.image = UIImage(named:"player")
        case 4:
            mLabel.text = "About Controller"
            mPickerView.isHidden = true
            mImageView.image = UIImage(named:"about")
        default:
            break
        }
    }
    
    @IBAction func unwindToStartVC(_ sender: UIStoryboardSegue) {
        if counterForGameVC > 1 {
            counterForGameVC -= 1
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        row_selected_from_pw = 0
        mSegmentedControl.selectedSegmentIndex = 0
        mLabel.text = "Calculation Controller"
        mPickerView.isHidden = true
        mImageView.image = UIImage(named:"calculation")
        mPickerView.selectRow(0, inComponent: 0, animated: true)
        selectedColor = #colorLiteral(red: 1, green: 0.2252420353, blue: 0.2439681457, alpha: 1)     // Write -> Color Literal
    }
    
    // 'Prepare for segue' function is used here for sending data to Game and About VCs through segues
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // For GameVC
        if let gameVC = segue.destination as? GameVC {
            gameVC.selected_color = selectedColor
            gameVC.counter = counterForGameVC
            gameVC.selected_row = row_selected_from_pw
        }
        
        // For AboutVC
        if segue.identifier == "toAbout" {
            if let aboutVC = segue.destination as? AboutVC {
                aboutVC.topText = "About Controller"
                aboutVC.centerText = "CTIS 480: Homework I"
                aboutVC.centerLabelColor = #colorLiteral(red: 0.4492385787, green: 0.09251748368, blue: 0.2881507218, alpha: 1)
                aboutVC.centerLabelStyle = UIFont.boldSystemFont(ofSize: 24)
            }
        }
    }
    
    
}

