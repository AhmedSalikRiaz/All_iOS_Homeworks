//
//  PlayerVC.swift
//  AhmedSalikRiaz_HW1
//
//  Created by CTIS Student on 27.10.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class PlayerVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource,  UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var bjkImg: UIImageView!
    @IBOutlet weak var fbImg: UIImageView!
    @IBOutlet weak var gsImg: UIImageView!
    
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var myPickerView: UIPickerView!
    
    var teamPlayers = [String]()
    var teamPlayersforpv = [String]()
    var flag_names = [String]()
    
    var imgname: String = ""
    var cnt_bjk: Int = 0
    var cnt_fb: Int = 0
    var cnt_gs: Int = 0
    var foo = [([String], [String])]()
    
    func populateDataforpv(team: String) {
        
        if let path = Bundle.main.path(forResource: "players", ofType: "plist") {
            if let dictArray = NSArray(contentsOfFile: path) {
                for item in dictArray {
                    if let dict = item as? NSDictionary {
                        if (dict.allKeys[0] as! String) == team {
                            teamPlayersforpv.append(dict.allValues[0] as! String)
                        }
                    }
                }
            }
        }
        
    }
    
    func populateData(team: String) {
        
        if let path = Bundle.main.path(forResource: "players", ofType: "plist") {
            if let dictArray = NSArray(contentsOfFile: path) {
                for item in dictArray {
                    if let dict = item as? NSDictionary {
                        if (dict.allKeys[0] as! String) == team {
                            teamPlayers.append(dict.allValues[0] as! String)
                            flag_names.append(team)
                        }
                    }
                }
            }
        }
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        teamPlayersforpv.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return teamPlayersforpv[row]
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        teamPlayers.count
        
    }
    
    // Filling the rows with data
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //var cell = UITableViewCell()
        
        // Recommended way
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        
        let (flag_name,player_name) = (flag_names[indexPath.row],teamPlayers[indexPath.row])
        cell.textLabel?.text = player_name
        
        
        
        
        let mImage = UIImage(named: flag_name)
        cell.imageView?.image = mImage
        
        return cell
    }
    
    @IBAction func besiktasTap(_ sender: UITapGestureRecognizer) {
        
        teamPlayersforpv.removeAll()
        
        if cnt_bjk < 1 {
            populateData(team: "besiktas")
        }
        
        populateDataforpv(team: "besiktas")
        
        cnt_bjk = 1
        imgname = "besiktas"
        
        myPickerView.reloadAllComponents()
        myTableView.reloadData()
    }
    
    @IBAction func fenerbahceTap(_ sender: UITapGestureRecognizer) {
        
        teamPlayersforpv.removeAll()
        
        if cnt_fb < 1 {
            populateData(team: "fenerbahce")
        }
        
        populateDataforpv(team: "fenerbahce")
        
        imgname = "fenerbahce"
        cnt_fb = 1
        
        myPickerView.reloadAllComponents()
        myTableView.reloadData()
    }
    
    @IBAction func galatasarayTap(_ sender: UITapGestureRecognizer) {
        
        teamPlayersforpv.removeAll()
        
        if cnt_gs < 1 {
            populateData(team: "galatasaray")
        }
        
        populateDataforpv(team: "galatasaray")
        
        imgname = "galatasaray"
        cnt_gs = 1
        
        myPickerView.reloadAllComponents()
        myTableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
