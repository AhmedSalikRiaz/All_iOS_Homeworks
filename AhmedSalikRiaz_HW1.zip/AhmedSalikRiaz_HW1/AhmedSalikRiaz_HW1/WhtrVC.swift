//
//  WhtrVC.swift
//  AhmedSalikRiaz_HW1
//
//  Created by CTIS Student on 27.10.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class WhtrVC: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var waistTxt: UITextField!
    @IBOutlet weak var heightTxt: UITextField!
    @IBOutlet weak var genderTxt: UILabel!
    @IBOutlet weak var switchBtn: UISwitch!
    @IBOutlet weak var calcResult: UILabel!
    @IBOutlet weak var descTxt: UILabel!
    
    var WHtR: Double?
    var isMale: Bool?
    var desc: String?
    
    @IBAction func onSwitchChange(_ sender: UISwitch) {
    
        if sender.isOn {
            isMale = true
            genderTxt.text = "(male):"
        }
        else{
            isMale = false
            genderTxt.text = "(female):"
        }
    }
    
    func healthDescription(_ sender: Double) {
        if isMale! {
            if sender < 35 {
                desc = "Abnormally Slim To Underweight"
            }
            else if sender >= 35 && sender < 43 {
                desc = "Extremely Slim"
            }
            else if sender >= 43 && sender < 46 {
                desc = "Slender and Healthy"
            }
            else if sender >= 46 && sender < 53 {
                desc = "Healthy, Normal Weight"
            }
            else if sender >= 53 && sender < 58 {
                desc = "OverWeight"
            }
            else if sender >= 58 && sender < 63 {
                desc = "Extremely OverWeight/Obese"
            }
            else if sender > 63 {
                desc = "Highly Obese"
            }
            
        }
        else{
            if sender < 35 {
                desc = "Abnormally Slim To Underweight"
            }
            else if sender >= 35 && sender < 42 {
                desc = "Extremely Slim"
            }
            else if sender >= 42 && sender < 46 {
                desc = "Slender and Healthy"
            }
            else if sender >= 46 && sender < 49 {
                desc = "Healthy, Normal Weight"
            }
            else if sender >= 49 && sender < 54 {
                desc = "OverWeight"
            }
            else if sender >= 54 && sender < 58 {
                desc = "Extremely OverWeight/Obese"
            }
            else if sender > 58 {
                desc = "Highly Obese"
            }
        }
    }
    @IBAction func onCalculationClick(_ sender: UIButton) {
        
        // resignFirstResponder will cause the textbox that currently has focus to release focus and the keyboard will hide
        self.waistTxt.resignFirstResponder()
        self.heightTxt.resignFirstResponder()
        
        let waist_val :Double? = Double(waistTxt.text!)
        let height_val :Double? = Double(heightTxt.text!)
        
        guard waist_val != nil && height_val != nil else {
            
              let alert = UIAlertController(title: "Warning", message: "The textfields cannot be empty!", preferredStyle: .alert)
              alert.addAction(UIAlertAction(title: NSLocalizedString("Close", comment: "Default action"), style: .default, handler: { _ in
              NSLog("The \"OK\" alert occured.")
              }))
            
              self.present(alert, animated: true, completion: nil)
              return
        }
        
        let WHtR = ((waist_val ?? 0) / (height_val ?? 0)) * 100
        
        // To round off the WHtR to 2 d.p.
        let roundedWHtR = round(WHtR * 100) / 100.0
        
        // Calculation results displayed
        if isMale! {
            calcResult.text = "WHtR (male): \(roundedWHtR)"
        }
        else{
            calcResult.text = "WHtR (female): \(roundedWHtR)"
        }
        
        healthDescription(roundedWHtR)
        descTxt.text = desc
    }
    
    // The textFieldShouldReturn method is called when the user taps the Return key
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           textField.resignFirstResponder()   // resignFirstResponder will cause the textbox that currently has focus to release focus and the keyboard will hide
           return true
    }
    
    // To close the keyboard when white area is pressed
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
         self.view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        // For initialization
        isMale = true
        WHtR = 0
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
