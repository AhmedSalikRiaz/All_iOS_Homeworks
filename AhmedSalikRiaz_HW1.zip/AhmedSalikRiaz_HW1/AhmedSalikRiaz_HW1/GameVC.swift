//
//  GameVC.swift
//  AhmedSalikRiaz_HW1
//
//  Created by CTIS Student on 29.10.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class GameVC: UIViewController {
    
    @IBOutlet weak var o1: UIImageView!
    @IBOutlet weak var o2: UIImageView!
    @IBOutlet weak var o3: UIImageView!
    
    @IBOutlet weak var e1: UIImageView!
    @IBOutlet weak var e2: UIImageView!
    @IBOutlet weak var e3: UIImageView!
    
    var selected_color: UIColor? = nil
    var selected_row: Int? = nil
    var counter: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
                
        print("Counter value: \(counter)")
        if counter % 2 == 0 {
            e1.backgroundColor = selected_color
            e2.backgroundColor = selected_color
            e3.backgroundColor = selected_color
        }
        else{
            o1.backgroundColor = selected_color
            o2.backgroundColor = selected_color
            o3.backgroundColor = selected_color
        }
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
