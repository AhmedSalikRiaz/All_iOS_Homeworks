//
//  CalculationVC.swift
//  AhmedSalikRiaz_HW1
//
//  Created by CTIS Student on 29.10.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class CalculationVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, InputVCDelegate {
    
    @IBOutlet weak var pickerV: UIPickerView!
    @IBOutlet weak var imageV: UIImageView!
    
    var shapes = ["Sphere","Cone","Cylinder"]
    var shape_item_name: String = ""
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        shapes.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return shapes[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        switch row {
        case 0:
            let img = UIImage(named: "sphere")
            imageV.image = img
            shape_item_name = shapes[row]
        case 1:
            let img = UIImage(named: "cone")
            imageV.image = img
            shape_item_name = shapes[row]
        case 2:
            let img = UIImage(named: "cylinder")
            imageV.image = img
            shape_item_name = shapes[row]
        default:
            let img = UIImage(named: "sphere")
            imageV.image = img
            shape_item_name = shapes[row]
            
            
        }
        
        
    }
    func AreaandVolumeDatas(data: (Double,Double,String)) {
        let (area, volume, item_name) = data
        
        let alert = UIAlertController(title: "Result", message: "\(item_name) Area = \(area) and Volume = \(volume)", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("Close", comment: "Default action"), style: .default, handler: { _ in
            NSLog("The \"OK\" alert occured.")
        }))
        self.present(alert, animated: true, completion: nil)
        
        
        
        
        
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "inputsegue" {
            if let VC = segue.destination as? InputVC {
                VC.title_for_input = shape_item_name
                VC.delegate = self
                
            }
        }
        
        
    }
    
    
}
